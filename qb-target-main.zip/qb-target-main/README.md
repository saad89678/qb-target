A redesign for QB-TARGET. Made for CodeForge, with a fresh style and related to the rest of Forge Scripts.

We have used the most updated version and modified its NUI. It's not our script, it's just a nice redesign.

https://github.com/C0deForge/qb-target/assets/125872426/cddff831-0250-48cb-9e5f-0a903aa0eaff

